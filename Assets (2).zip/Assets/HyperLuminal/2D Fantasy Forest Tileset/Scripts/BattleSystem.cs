using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class BattleSystem : MonoBehaviour
{
    public GameObject player;
    public GameObject enemy;
    public TextMeshProUGUI battleText;
    public Button attackButton;
    public Button runButton;

    int enemyHP;
    private PlayerHealth playerHealth;

    void Start()
    {
        playerHealth = FindObjectOfType<PlayerHealth>();

        if (playerHealth == null)
        {
            Debug.LogError("BattleSystem: '��'���� 'PlayerHealth' ��ũ��Ʈ�� ã�� �� �����ϴ�!");
        }

        if (GameManager.instance != null)
        {
            string encounteredEnemyName = GameManager.instance.currentEnemyName;
            Sprite encounteredEnemySprite = GameManager.instance.currentEnemyBattleSprite;
            enemyHP = GameManager.instance.currentEnemyHP;

            if (enemy != null && encounteredEnemySprite != null)
            {
                SpriteRenderer enemySpriteRenderer = enemy.GetComponent<SpriteRenderer>();
                if (enemySpriteRenderer != null)
                {
                    enemySpriteRenderer.sprite = encounteredEnemySprite;
                }
            }

            battleText.text = encounteredEnemyName + " ��(��) ��Ÿ����!";
        }
        else
        {
            Debug.LogError("GameManager�� ���� �����ϴ�! �� ������ �ҷ��� �� �����ϴ�.");
            battleText.text = "���ʹ�!";
            enemyHP = 5;
        }

        attackButton.onClick.AddListener(OnAttack);
        runButton.onClick.AddListener(OnRun);
    }

    void OnAttack()
    {
        attackButton.interactable = false;
        runButton.interactable = false;
        int damage = Random.Range(1, 3);
        enemyHP -= damage;
        battleText.text = "����! ���Ϳ��� " + damage + "�������� ������";
        if (enemyHP <= 0)
        {
            battleText.text = "���͸� �����ƴ�!";
            Invoke("ReturnToMainScene", 1.5f);
        }
        else
        {
            Invoke("EnemyTurn", 1.0f);
        }
    }

    void EnemyTurn()
    {
        int damage = Random.Range(1, 3);
        if (playerHealth != null)
        {
            playerHealth.TakeDamage(damage);
        }
        battleText.text = "���� �ݰ� " + damage + "�������� �Ծ���";
        if (GameManager.instance.playerCurrentHP <= 0)
        {
            battleText.text = "��������";
            Invoke("ReturnToMainScene", 1.5f);
        }
        else
        {
            attackButton.interactable = true;
            runButton.interactable = true;
        }
    }

    void OnRun()
    {
        battleText.text = "�����ƴ�";
        attackButton.interactable = false;
        runButton.interactable = false;
        Invoke("ReturnToMainScene", 1.5f);
    }

    void ReturnToMainScene()
    {
        SceneManager.LoadScene("DayTime_DemoScene");
    }
}