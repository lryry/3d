using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class BattleSystem : MonoBehaviour
{
    public GameObject player;
    public GameObject enemy;
    public TextMeshProUGUI battleText;
    public Button attackButton;
    public Button runButton;

    int playerHP = 10;
    int enemyHP = 5;

    void Start()
    {
        battleText.text = "It's a monster!"; //���ʹ� 
        attackButton.onClick.AddListener(OnAttack);
        runButton.onClick.AddListener(OnRun);
    }

    void OnAttack()
    {
        int damage = Random.Range(1, 3);
        enemyHP -= damage;
        battleText.text = "Attack! To the monster " + damage + "I caused damage"; //����! ���Ϳ��� �������� ������

        if (enemyHP <= 0)
        {
            battleText.text = "I defeated the monster!"; // ���͸� �����ƴ�
            SceneManager.LoadScene("DayTime_DemoScene");
        }
        else
        {
            Invoke("EnemyTurn", 1.0f);
        }
    }

    void EnemyTurn()
    {
        int damage = Random.Range(1, 3);
        playerHP -= damage;
        battleText.text = "Monster's Counterattack " + damage + "I suffered damage from the damage"; //���� �ݰ�, �������� �Ծ���

        if (playerHP <= 0)
        {
            battleText.text = "It fell down"; //��������
            SceneManager.LoadScene("DayTime_DemoScene");

        }
    }

    void OnRun()
    {
        battleText.text = "ran away"; //�����ƴ�
        SceneManager.LoadScene("DayTime_DemoScene");
    }
}
