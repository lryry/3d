﻿using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("이동 설정")]
    [SerializeField] private float movementSpeed = 5.0f;

    private Animator animator;
    private Rigidbody2D rb;
    private SpriteRenderer sr;

    private Vector3 CheckPointPosition;
    private bool isDead = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();

        CheckPointPosition = transform.position;

        // Rigidbody2D 설정
        rb.gravityScale = 0;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    void Update()
    {
        // ESC로 종료
        if (Input.GetKeyDown(KeyCode.Escape))
            Application.Quit();

        if (isDead)
        {
            rb.linearVelocity = Vector2.zero;
            if (animator != null) animator.speed = 0f;
            return;
        }

        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        Vector2 move = new Vector2(horizontal, vertical).normalized * movementSpeed;
        rb.linearVelocity = move;

        // 좌우 반전
        if (horizontal > 0) sr.flipX = false;
        else if (horizontal < 0) sr.flipX = true;

        // 애니메이터 파라미터 설정
        if (animator != null)
        {
            animator.SetFloat("MoveX", horizontal);
            animator.SetFloat("MoveY", vertical);
            animator.SetFloat("Speed", move.sqrMagnitude);
        }

        // 항상 Z=0으로 고정 (Z축 이동 방지)
        transform.position = new Vector3(transform.position.x, transform.position.y, 0f);
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.CompareTag("DangerousTile"))
        {
            GameObject.Find("FadePanel").GetComponent<FadeScript>().RespawnFade();
            isDead = true;
        }
        else if (collider.CompareTag("LevelChanger"))
        {
            GameObject.Find("FadePanel").GetComponent<FadeScript>().FadeOut();
            isDead = true;
        }
    }

    public void RespawnPlayerAtCheckpoint()
    {
        transform.position = CheckPointPosition;
        isDead = false;
    }
}
